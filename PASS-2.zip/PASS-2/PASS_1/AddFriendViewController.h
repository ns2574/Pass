//
//  AddFriendViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/25/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendViewController : UIViewController











@end
