//
//  AddToChatViewController.h
//  PASS_1
//
//  Created by Shiny Croospulle on 4/25/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddToChatViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITableView *friendsList;
@property (weak, nonatomic) IBOutlet UISearchBar *searchBar;

@end
