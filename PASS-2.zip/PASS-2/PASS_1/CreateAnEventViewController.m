//
//  CreateAnEventViewController.m
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "CreateAnEventViewController.h"
#import "SingleEventInfo.h"

@interface CreateAnEventViewController ()

@end

@implementation CreateAnEventViewController

@synthesize eventTitleInput, eventDescriptionInput, streetAddressInput, cityInput, stateInput, zipcodeInput, eventImageInput, takePhoto, uploadPhoto, createEvent, aNewEvent;

- (BOOL) textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    
    if([text isEqualToString:@"\n"]) {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.eventTitleInput.delegate = self;
    self.streetAddressInput.delegate = self;
    self.cityInput.delegate = self;
    self.stateInput.delegate = self;
    self.zipcodeInput.delegate = self;
    
    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

-(IBAction)saveInfo:(id)sender
{
    
    aNewEvent.eName = self.eventTitleInput.text;
    aNewEvent.eDescription = self.eventDescriptionInput.text;
    aNewEvent.eStreetAddress = self.streetAddressInput.text;
    aNewEvent.eCity = self.cityInput.text;
    aNewEvent.eState = self.stateInput.text;
    aNewEvent.eZip = [self.zipcodeInput.text intValue ];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
