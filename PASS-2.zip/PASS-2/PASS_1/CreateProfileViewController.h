//
//  CreateProfileViewController.h
//  PASS_1
//
//  Created by Shiny Croospulle on 4/25/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CreateProfileViewController : UIViewController <UIImagePickerControllerDelegate, UIImagePickerControllerDelegate > {
    UIImagePickerController *picker;
    UIImagePickerController *picker2;
    UIImage *image;
    IBOutlet UIImageView *imageView;
}


@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *school;
@property (nonatomic, strong) NSString *job;
@property (nonatomic, strong) NSString *birthday;
@property (nonatomic, strong) NSString *city;


@property (strong, nonatomic) IBOutlet UILabel *userName;

@property (strong, nonatomic) IBOutlet UILabel *userSchool;

@property (strong, nonatomic) IBOutlet UILabel *userJob;

@property (strong, nonatomic) IBOutlet UILabel *userBirthday;

@property (strong, nonatomic) IBOutlet UILabel *userCity;

@property (weak, nonatomic) IBOutlet UIButton *save;

@property (weak, nonatomic) IBOutlet UIButton *help;

-(id) initWithUserName:(NSString *) uName andUserSchool: (NSString *) uSchool andUserJob: (NSString *) uJob andUserBirthday: (NSString *) uBirthday andUSerCity: (NSString *) uCity;

-(IBAction)TakePhoto;
-(IBAction)ChooseExisting;

#pragma mark - Methods 
- (void) retriveData;


@end
