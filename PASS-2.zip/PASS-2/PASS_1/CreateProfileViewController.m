//
//  CreateProfileViewController.m
//  PASS_1
//
//  Created by Shiny Croospulle on 4/25/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "CreateProfileViewController.h"

@interface CreateProfileViewController ()

@end

#define getDataURL @"https://passus.poly.edu/"

@implementation CreateProfileViewController
@synthesize userName, userSchool, userJob, userBirthday, userCity;

-(id) initWithUserName:(NSString *) uName andUserSchool: (NSString *) uSchool andUserJob: (NSString *) uJob andUserBirthday: (NSString *) uBirthday andUSerCity: (NSString *) uCity {
    
    self = [super init];
    if (self) {
        
        userName = uName;
        userSchool = uSchool;
        userJob = uJob;
        userBirthday = uBirthday;
        userCity = uCity;
    }
    
    return self;
}

-(IBAction)TakePhoto{
    picker = [[UIImagePickerController alloc]init];
    picker.delegate = self;
    [picker setSourceType:UIImagePickerControllerSourceTypeCamera];
    [self presentViewController:picker animated:YES completion:NULL];
}

-(IBAction)ChooseExisting {
    picker2 = [[UIImagePickerController alloc]init];
    picker2.delegate = self;
    [picker2 setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [self presentViewController:picker2 animated:YES completion:NULL];
}

-(void) imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [imageView setImage:image];
    [self dismissViewControllerAnimated:YES completion:NULL];
                         
}

-(void) imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:NULL];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
  /*
    userName = _name;
    userSchool = _school;
    userJob = _job;
    userBirthday = _birthday;
    userCity = _city;
   
   */
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Methods
- (void) retriveData {
    NSURL * url = [NSURL URLWithString:getDataURL];
    NSData * data = [NSData dataWithContentsOfURL:url];
    
    //json = [NSJSONSerialization JSONObjectWithData:data options:kNilOptions error:nil];

    
}

@end
