//
//  CurrentLocationViewController.m
//  PASS_1
//
//  Created by Shiny Croospulle on 4/16/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "CurrentLocationViewController.h"

@interface CurrentLocationViewController () <MKMapViewDelegate> {
    
    __weak IBOutlet MKMapView *myMapView;
    
    CLLocationManager *locationManager;
}

@end

@implementation CurrentLocationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    myMapView.showsUserLocation = YES;
    myMapView.showsBuildings = YES;
    
    locationManager = [CLLocationManager new];
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [locationManager requestWhenInUseAuthorization];
    }
    
    [locationManager startUpdatingLocation];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation {
    
    MKMapCamera *camera = [MKMapCamera cameraLookingAtCenterCoordinate:userLocation.coordinate fromEyeCoordinate:CLLocationCoordinate2DMake(userLocation.coordinate.latitude, userLocation.coordinate.longitude)eyeAltitude:10000];
    [mapView setCamera:camera animated:YES];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
