//
//  EventsPageViewController.m
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "EventsPageViewController.h"
#import "SingleEventInfo.h"
#import "ViewAnEventViewController.h"
#import "ViewJoinedEventsViewController.h"


@interface EventsPageViewController ()

@property(strong)NSArray *nameOfEvents;

@property(strong)NSArray *eventsIMade;

@end

@implementation EventsPageViewController

@synthesize eventNearMe, myEvent, nameOfEvents, eventsIMade;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    SingleEventInfo *s1 = [[SingleEventInfo alloc] initWithaName:@"Pool Party" eDescription:@"Going to be a new pool, avoid eye contact with water!" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    SingleEventInfo *s2 = [[SingleEventInfo alloc] initWithaName:@"Shiny House Warming" eDescription:@"Lots of food!" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    SingleEventInfo *s3 = [[SingleEventInfo alloc] initWithaName:@"Elon's Birthday" eDescription:@"Many treat and possibly cake will be provided!" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    SingleEventInfo *s4 = [[SingleEventInfo alloc] initWithaName:@"Jesus's cincianera" eDescription:@"Dancing with the mexicans!" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    
    
    SingleEventInfo *m1 = [[SingleEventInfo alloc] initWithaName:@"Cassie's bday" eDescription:@"I will be there" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    SingleEventInfo *m2 = [[SingleEventInfo alloc] initWithaName:@"taco tuesday"eDescription:@"I will be there" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    SingleEventInfo *m3 = [[SingleEventInfo alloc] initWithaName:@"TGIF" eDescription:@"I will be there" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    SingleEventInfo *m4 = [[SingleEventInfo alloc] initWithaName:@"Red Mango Mania" eDescription:@"I will be there" eStreetAdress:@"55 Clark St" eCity:@"Brooklyn" eState:@"NY" eZip:11201];
    
    
    
    self.nameOfEvents = [NSArray arrayWithObjects: s1, s2, s3, s4 , nil];
    
    self.eventsIMade = [NSArray arrayWithObjects: m1, m2, m3, m4, nil];
    

    // Do any additional setup after loading the view.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(NSInteger)tableView: (UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView == self.eventNearMe){
        return [self.nameOfEvents count];
    }
    else if(tableView == self.myEvent){
        return [self.eventsIMade count];
    }
    return 0;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"ViewAnEventSegue"]){
        UITableViewCell *cell = (UITableViewCell *)sender;
        UITableView *tableView = self.eventNearMe;
        if (self.eventNearMe) {
            NSIndexPath *ip = [tableView indexPathForCell:cell];
            SingleEventInfo *s1 = [self.nameOfEvents objectAtIndex:ip.row];
            
            ViewAnEventViewController *vae = (ViewAnEventViewController *)segue.destinationViewController;
            vae.event = s1;
        }
    }
    else if([segue.identifier isEqualToString:@"ViewJoinedEventsSegue"]){
        UITableViewCell *cell = (UITableViewCell *)sender;
        UITableView *tableView = self.myEvent;
        if(self.myEvent){
            NSIndexPath *ip = [tableView indexPathForCell:cell];
            SingleEventInfo *s2 = [self.eventsIMade objectAtIndex:ip.row];
            
            ViewAnEventViewController *vae1 = (ViewAnEventViewController *)segue.destinationViewController;
            vae1.event = s2;
        }
    }
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    
    
    if(tableView == self.eventNearMe){
        
        SingleEventInfo *s = [self.nameOfEvents objectAtIndex:indexPath.row];
        cell.textLabel.text = s.eName;
    }
    
    else if(tableView == self.myEvent){
        
        SingleEventInfo *m = [self.eventsIMade objectAtIndex:indexPath.row];
        cell.textLabel.text = m.eName;
        
    }
    return cell;
}



/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
}
*/

@end
