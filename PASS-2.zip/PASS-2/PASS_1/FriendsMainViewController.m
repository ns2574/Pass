//
//  FriendsMainViewController.m
//  PASS_1
//
//  Created by Niela Sultana on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "FriendsMainViewController.h"
#import "friendCLass.h"
#import "ViewFriendViewController.h"


@interface FriendsMainViewController ()

@property(strong)NSArray *listOfFriends;
@end

@implementation FriendsMainViewController

@synthesize friendToView, hideFromAllFriends, addFriend;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    friendCLass *f1 = [[friendCLass alloc] initWithaName:@"Jesus" fLastName:@"Leal" fhighSchool:@"Brooklyn Tech" fcollege: @"NYU Tandon" fcurrentJob:@"El POPO" foldJob:@"N/A" fbirthday:@"May 7, 1994" fcountryOfOrigin:@"Mexico" fareaInfo:@"Brooklyn, NY" f_id: NULL  fLocation:nil];
    
    friendCLass *f2 = [[friendCLass alloc] initWithaName:@"Elon" fLastName:@"Xie" fhighSchool:@"Brooklyn Tech" fcollege: @"NYU Tandon" fcurrentJob:@"IT at hospital" foldJob:@"Student teacher" fbirthday:@"December 2nd, 1995" fcountryOfOrigin:@"China" fareaInfo:@"Brooklyn, NY" f_id: NULL  fLocation:nil];
    
    self.listOfFriends = [NSArray arrayWithObjects: f1, f2, nil];
  
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(NSInteger)tableView: (UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(tableView == friendToView){
        return [self.listOfFriends count];
    }
    return 0;
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"ViewFriendSegue"]){
        UITableViewCell *cell = (UITableViewCell *)sender;
        UITableView *tableView = self.friendToView;
        
        if(self.friendToView) {
            
            NSIndexPath *ip = [tableView indexPathForCell:cell];
            
            friendCLass *f1 = [self.listOfFriends objectAtIndex:ip.row];
            
            ViewFriendViewController *vf = (ViewFriendViewController *)segue.destinationViewController;
            
            vf.afriend = f1;
        }
    }

}

/*
 if([segue.identifier isEqualToString:@"ViewAnEventSegue"]){
 UITableViewCell *cell = (UITableViewCell *)sender;
 UITableView *tableView = self.eventNearMe;
 
 if (self.eventNearMe) {
 NSIndexPath *ip = [tableView indexPathForCell:cell];
 SingleEventInfo *s1 = [self.nameOfEvents objectAtIndex:ip.row];
 
 ViewAnEventViewController *vae = (ViewAnEventViewController *)segue.destinationViewController;
 vae.event = s1;
 }
 
 */



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    
    if(cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    
    
    if(tableView == friendToView) {
        
        friendCLass *fc = [self.listOfFriends objectAtIndex:indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@ %@", fc.fFirstName, fc.fLastName];
    }
    
    return cell;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
