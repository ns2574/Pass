//
//  RequestFriendViewController.h
//  PASS_1
//
//  Created by Shiny Croospulle on 4/25/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RequestFriendViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *userImage;

@property (strong, nonatomic) IBOutlet UILabel *userName;

@property (strong, nonatomic) IBOutlet UILabel *userSchool;

@property (strong, nonatomic) IBOutlet UILabel *userJob;

@property (strong, nonatomic) IBOutlet UILabel *userBirthday;

@property (strong, nonatomic) IBOutlet UILabel *userCity;

@property (weak, nonatomic) IBOutlet UIButton *back;

@property (weak, nonatomic) IBOutlet UIButton *requestFriend;



@end
