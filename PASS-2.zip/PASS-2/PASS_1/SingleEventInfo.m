//
//  SingleEventInfo.m
//  PASS_1
//
//  Created by Niela Sultana on 4/19/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "SingleEventInfo.h"

@interface SingleEventInfo ()

@end

@implementation SingleEventInfo

@synthesize eName, eDescription, eStreetAddress, eCity, eState, eZip;

-(id)initWithaName:(NSString *)aName eDescription:(NSString *)aDescription eStreetAdress:(NSString *)aStreetAddress eCity:(NSString *)aCity eState:(NSString *)aState eZip:(int)aZip{
    self = [super init];
    if(self){
        self.eName = aName;
        self.eDescription = aDescription;
        self.eStreetAddress = aStreetAddress;
        self.eCity = aCity;
        self.eState = aState;
        self.eZip = aZip;
        
    }
    return self;
}

@end
