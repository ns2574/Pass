//
//  ViewAnEventViewController.m
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "ViewAnEventViewController.h"
#import "SingleEventInfo.h"

@interface ViewAnEventViewController ()

@end

@implementation ViewAnEventViewController




@synthesize eventNameOutput, eventDescriptionOutput, streetAddressOutput, areaInfoOutput, eventImage, event;

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.eventNameOutput.text = self.event.eName;
    self.eventDescriptionOutput.text = self.event.eDescription;
    self.streetAddressOutput.text = self.event.eStreetAddress;
    self.areaInfoOutput.text = [NSString stringWithFormat:@"%@ %@ %d",self.event.eCity,self.event.eState,self.event.eZip];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
