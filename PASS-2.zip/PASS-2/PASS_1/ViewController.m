//
//  ViewController.m
//  PASS_1
//
//  Created by Shiny Croospulle on 4/16/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "ViewController.h"
#import "ASIFormDataRequest.h"


@interface ViewController ()

@property NSDictionary *jsonObject;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    NSURL *url=[NSURL URLWithString:@"http://www.passus.nyu.edu/index"];
    ASIFormDataRequest *request=[ASIFormDataRequest requestWithURL:url];
    [request setRequestMethod:@"POST"];
    [request setPostValue:@"egg" forKey:@"ingredient"];
    [request startSynchronous];
    NSString *response = [request responseString];
    NSLog(@"responseString is %@",response);
    
    NSData *theJSON = [request responseData];
    
    NSLog(@"theJSON is %@",theJSON);
    
    _jsonObject=[NSJSONSerialization
                 JSONObjectWithData:theJSON
                 options:NSJSONReadingMutableLeaves
                 error:nil];
    
    NSLog(@"jsonObject is %@",_jsonObject);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
