//
//  ViewFriendViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "friendCLass.h"

@interface ViewFriendViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *nameOfFriend;

@property (weak, nonatomic) IBOutlet UILabel *highSchool;

@property (weak, nonatomic) IBOutlet UILabel *college;

@property (weak, nonatomic) IBOutlet UILabel *friendsBirthday;

@property (weak, nonatomic) IBOutlet UILabel *countryOrigin;

@property (weak, nonatomic) IBOutlet UILabel *whereFriendLives;

@property (weak, nonatomic) IBOutlet UILabel *currentJob;

@property (weak, nonatomic) IBOutlet UILabel *oldJob;


@property (weak, nonatomic) IBOutlet UIButton *deleteFriend;

@property (weak, nonatomic) IBOutlet UIButton *hideFriend;

@property(strong, nonatomic) friendCLass *afriend;

@end
