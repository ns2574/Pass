//
//  ViewFriendViewController.m
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "ViewFriendViewController.h"
#import "friendCLass.h"


@interface ViewFriendViewController ()

@end

@implementation ViewFriendViewController

@synthesize nameOfFriend, highSchool, college, friendsBirthday, currentJob, oldJob, countryOrigin, whereFriendLives, deleteFriend, hideFriend, afriend;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.nameOfFriend.text = [NSString stringWithFormat:@"%@ %@", self.afriend.fFirstName, self.afriend.fLastName];
    self.highSchool.text = self.afriend.fhighSchool;
    self.college.text = self.afriend.fcollege;
    self.currentJob.text = self.afriend.fcurrentJob;
    self.oldJob.text = self.afriend.foldJob;
    self.friendsBirthday.text = self.afriend.fbirthday;
    self.countryOrigin.text = self.afriend.fcountryOfOrigin;
    self.whereFriendLives.text = self.afriend.fareaInfo;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
