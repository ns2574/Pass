//
//  ViewJoinedEventsViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SingleEventInfo.h"

@interface ViewJoinedEventsViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *nameOfEventJoined;


@property (weak, nonatomic) IBOutlet UITextView *desriptionOfEventJoined;


@property (weak, nonatomic) IBOutlet UILabel *streetAddress;

@property (weak, nonatomic) IBOutlet UILabel *areaOfEvent;


@property (weak, nonatomic) IBOutlet UIButton *getDirection;


@property (weak, nonatomic) IBOutlet UIButton *leaveEvent;

@property (weak, nonatomic) IBOutlet UIImageView *eventImage;

@property(strong, nonatomic) SingleEventInfo *event;


@end
