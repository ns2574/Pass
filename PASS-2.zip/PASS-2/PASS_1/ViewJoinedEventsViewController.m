//
//  ViewJoinedEventsViewController.m
//  PASS_1
//
//  Created by Niela Sultana on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "ViewJoinedEventsViewController.h"
#import "SingleEventInfo.h"

@interface ViewJoinedEventsViewController ()

@end

@implementation ViewJoinedEventsViewController


@synthesize nameOfEventJoined, desriptionOfEventJoined, streetAddress, areaOfEvent, getDirection, leaveEvent;


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.nameOfEventJoined.text = self.event.eName;
    self.desriptionOfEventJoined.text = self.event.eDescription;
    self.streetAddress.text = self.event.eStreetAddress;
    self.areaOfEvent.text = [NSString stringWithFormat:@"%@ %@ %d",self.event.eCity,self.event.eState,self.event.eZip];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
