//
//  ViewRequestViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/25/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewRequestViewController : UIViewController


@property (weak, nonatomic) IBOutlet UIImageView *userImage;


@property (weak, nonatomic) IBOutlet UILabel *userHS;

@property (weak, nonatomic) IBOutlet UILabel *userCollege;

@property (weak, nonatomic) IBOutlet UILabel *currentJob;

@property (weak, nonatomic) IBOutlet UILabel *previousJob;

@property (weak, nonatomic) IBOutlet UILabel *birthday;


@property (weak, nonatomic) IBOutlet UILabel *countryOfUser;


@property (weak, nonatomic) IBOutlet UILabel *currentAddress;


@property (weak, nonatomic) IBOutlet UIButton *acceptRequest;



@end
