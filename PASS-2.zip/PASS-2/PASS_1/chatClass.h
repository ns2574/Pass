//
//  chatClass.h
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>
#include "chatLineClass.h"

@interface chatClass : NSObject

@property(strong)NSString *cChat_id;
@property(strong)NSMutableArray *cChatLines;
@property(strong)NSString *cChatType;
@property(strong)NSString *creator_id;

-(id)initWithaID:(NSString *)chatId cChatLines:(NSMutableArray *)chatLines cChatType: (NSString *)chatType  creator_id: (NSString *) cid;

@end
