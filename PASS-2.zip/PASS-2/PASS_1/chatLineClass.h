//
//  chatLineClass.h
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface chatLineClass : NSObject

@property(strong)NSString *cChatLine;
@property int *cLine_id;
@property(strong)NSString *cu_id;
@property(strong)NSString *cTimeStamp;

-(id)initWithaLine:(NSString *)chatLine cLine_id:(int *)line_id cu_id: (NSString *) uid  cTimeStamp: (NSString *) timeStamp;


@end
