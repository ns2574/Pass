//
//  chatLineClass.m
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "chatLineClass.h"
@interface chatLineClass()
@end

@implementation chatLineClass

@synthesize cChatLine, cLine_id, cu_id, cTimeStamp;

-(id)initWithaLine:(NSString *)chatLine cLine_id:(int *)line_id cu_id: (NSString *) uid  cTimeStamp: (NSString *) timeStamp{
    self = [super init];
    if(self){
        self.cChatLine = chatLine;
        self.cLine_id = line_id;
        self.cu_id = uid;
        self.cTimeStamp = timeStamp;
    }
    return self;
}

@end
