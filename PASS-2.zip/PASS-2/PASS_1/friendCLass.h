//
//  friendCLass.h
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "locationClass.h"


@interface friendCLass : NSObject

@property(strong)NSString *fFirstName;
@property(strong)NSString *fLastName;
@property(strong)NSString *fhighSchool;
@property(strong)NSString *fcollege;
@property(strong)NSString *fcurrentJob;
@property(strong)NSString *foldJob;
@property(strong)NSString *fbirthday;
@property(strong)NSString *fcountryOfOrigin;
@property(strong)NSString *fareaInfo;
@property(strong)NSString *f_id;
@property(strong)locationClass *fLocation;

-(id)initWithaName:(NSString *)firstName fLastName:(NSString *)lastName fhighSchool: (NSString *) highSchool fcollege: (NSString *) college fcurrentJob: (NSString *) currentJob foldJob: (NSString *) oldJob fbirthday: (NSString *) birthday fcountryOfOrigin: (NSString *) countryOfOrigin fareaInfo: (NSString *) areaInfo f_id: (NSString *) fid  fLocation: (locationClass *) location;


@end
