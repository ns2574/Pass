//
//  friendCLass.m
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "friendCLass.h"

@interface friendCLass()

@end

@implementation friendCLass

@synthesize fFirstName, fLastName, fhighSchool,  fcollege, fcurrentJob, foldJob, fbirthday,fcountryOfOrigin, fareaInfo, f_id, fLocation;

-(id)initWithaName:(NSString *)firstName fLastName:(NSString *)lastName fhighSchool: (NSString *) highSchool fcollege: (NSString *) college fcurrentJob: (NSString *) currentJob foldJob: (NSString *) oldJob fbirthday: (NSString *) birthday fcountryOfOrigin: (NSString *) countryOfOrigin fareaInfo: (NSString *) areaInfo f_id: (NSString *) fid  fLocation: (locationClass *) location{
    self = [super init];
    if(self){
        self.fFirstName = firstName;
        self.fLastName = lastName;
        self.fhighSchool = highSchool;
        self.fcollege = college;
        self.fcurrentJob = currentJob;
        self.foldJob = oldJob;
        self.fbirthday = birthday;
        self.fcountryOfOrigin = countryOfOrigin;
        self.fareaInfo = areaInfo;
        self.f_id = fid;
        self.fLocation = location;
        
    }
    return self;
}

@end
