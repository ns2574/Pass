//
//  loginViewController.m
//  PASS_1
//
//  Created by Shiny Croospulle on 4/16/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "loginViewController.h"

@interface loginViewController ()

@end

@implementation loginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    if(![defaults boolForKey:@"registered"]) {
        NSLog(@"No user registered");
        _loginBtn.hidden = YES;
    }
    else {
        NSLog(@"User is registered");
        _reEnterPassword.hidden = YES;
        _signupBtn.hidden = YES;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)SignUpUser:(id)sender {
    if([_email.text isEqualToString:@""] || [_password.text isEqualToString:@""] || [_reEnterPassword.text isEqualToString:@""]) {
        
        UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"You must complete all fields" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                              [error show];
    }
    else {
        [self checkPasswordsMatch];
    }
}

-(void) checkPasswordsMatch {
    if([_password.text isEqualToString:_reEnterPassword.text]){
        NSLog(@"passwords match!");
        [self registerNewUser];
    }
    else {
        UIAlertView *error = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Passwords do not match" delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [error show];
    }
}

-(void) registerNewUser {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    
    [defaults setObject:_email.text forKey:@"email"];
    [defaults setObject:_password.text forKey:@"password"];
    [defaults setBool:YES forKey:@"registered"];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


- (IBAction)LoginUser:(id)sender {
}

@end
