//
//  userClass.h
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "locationClass.h"
#import "SingleEventInfo.h"
#import "friendClass.h"
#import "chatClass.h"

@interface userClass : NSObject


@property(strong)NSString *uFirstName;
@property(strong)NSString *uLastName;
@property(strong)NSString *u_id;
@property(strong)NSString *uPassword;
@property(strong)locationClass *uLocation;
@property(strong)NSString *uSessionCookie;
@property(strong)NSMutableArray *uEvents;
@property(strong)NSMutableArray *uFriends;
@property(strong)NSMutableArray *uChats;


-(id)initWithaName:(NSString *)firstName uLastName:(NSString *)lastName u_id: (NSString *) uid uPassword: (NSString *) password uLocation: (locationClass *) location uSessionCookie: (NSString *) sessionCookie uEvents: (NSMutableArray *) events uFriends: (NSMutableArray *) friends uChats: (NSMutableArray *) chats;



@end
