//
//  ChatHomePageViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatHomePageViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITableView *chat;

@property (weak, nonatomic) IBOutlet UIButton *startNewChat;

@end
