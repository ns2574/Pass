//
//  CreateAnEventViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SingleEventInfo.h"

@interface CreateAnEventViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *eventTitleInput;

@property (weak, nonatomic) IBOutlet UITextView *eventDescriptionInput;

@property (weak, nonatomic) IBOutlet UITextField *streetAddressInput;

@property (weak, nonatomic) IBOutlet UITextField *cityInput;

@property (weak, nonatomic) IBOutlet UITextField *stateInput;

@property (weak, nonatomic) IBOutlet UITextField *zipcodeInput;


@property (weak, nonatomic) IBOutlet UIButton *createEvent;


@end
