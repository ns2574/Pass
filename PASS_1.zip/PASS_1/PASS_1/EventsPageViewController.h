//
//  EventsPageViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventsPageViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITableView *eventNearMe;


@property (weak, nonatomic) IBOutlet UITableView *myEvent;


@end
