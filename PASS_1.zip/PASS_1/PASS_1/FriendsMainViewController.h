//
//  FriendsMainViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FriendsMainViewController : UIViewController


@property (weak, nonatomic) IBOutlet UITableView *friendToView;


@property (weak, nonatomic) IBOutlet UIButton *hideFromAllFriends;


@property (weak, nonatomic) IBOutlet UIButton *addFriend;



@end
