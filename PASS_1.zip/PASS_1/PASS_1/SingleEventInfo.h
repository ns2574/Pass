//
//  SingleEventInfo.h
//  PASS_1
//
//  Created by Niela Sultana on 4/19/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SingleEventInfo : NSObject

@property(strong)NSString *eName;
@property(strong)NSString *eDescription;
@property(strong)NSString *eStreetAddress;
@property(strong)NSString *eCity;
@property(strong)NSString *eState;
@property int eZip;

-(id)initWithaName:(NSString *)aName eDescription:(NSString *)aDescription eStreetAdress:(NSString *)aStreetAddress eCity:(NSString *)aCity eState:(NSString *)aState eZip:(int)aZip;

@end
