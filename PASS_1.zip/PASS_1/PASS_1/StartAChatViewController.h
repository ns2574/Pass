//
//  StartAChatViewController.h
//  PASS_1
//
//  Created by Niela Sultana on 4/17/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StartAChatViewController : UIViewController

@property (weak, nonatomic) IBOutlet UITextField *findFriend;

@property (weak, nonatomic) IBOutlet UITableView *matchedFriend;

@property (weak, nonatomic) IBOutlet UITextView *firstMessage;


@property (weak, nonatomic) IBOutlet UIButton *sendMessage;


@end
