//
//  chatClass.m
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "chatClass.h"
@interface chatClass()
@end

@implementation chatClass

@synthesize cChat_id, cChatLines, cChatType, creator_id;

-(id)initWithaID:(NSString *)chatId cChatLines:(NSMutableArray *)chatLines cChatType: (NSString *)chatType  creator_id: (NSString *) cid{
    self = [super init];
    if(self){
        self.cChat_id = chatId;
        self.cChatLines= chatLines;
        self.cChatType = chatType;
        self.creator_id = cid;
        
    }
    return self;
}

@end
