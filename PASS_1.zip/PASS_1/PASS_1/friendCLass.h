//
//  friendCLass.h
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "locationClass.h"


@interface friendCLass : NSObject

@property(strong)NSString *fFirstName;
@property(strong)NSString *fLastName;
@property(strong)NSString *f_id;
@property(strong)locationClass *fLocation;

-(id)initWithaName:(NSString *)firstName fLastName:(NSString *)lastName f_id: (NSString *) fid  fLocation: (locationClass *) location;


@end
