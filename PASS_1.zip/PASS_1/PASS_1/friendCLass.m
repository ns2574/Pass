//
//  friendCLass.m
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "friendCLass.h"

@interface friendCLass()

@end

@implementation friendCLass

@synthesize fFirstName, fLastName, f_id, fLocation;

-(id)initWithaName:(NSString *)firstName fLastName:(NSString *)lastName f_id: (NSString *) fid fLocation: (locationClass *) location{
    self = [super init];
    if(self){
        self.fFirstName = firstName;
        self.fLastName = lastName;
        self.f_id = fid;
        self.fLocation = location;
        
    }
    return self;
}

@end
