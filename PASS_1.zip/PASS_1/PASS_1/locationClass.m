//
//  locationClass.m
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "locationClass.h"

@implementation locationClass

@end
