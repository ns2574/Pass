//
//  loginViewController.h
//  PASS_1
//
//  Created by Shiny Croospulle on 4/16/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface loginViewController : UIViewController
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *reEnterPassword;

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *signupBtn;

- (IBAction)LoginUser:(id)sender;
- (IBAction)SignUpUser:(id)sender;

@end
