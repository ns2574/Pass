//
//  userClass.m
//  PASS_1
//
//  Created by Jesus Leal on 4/24/16.
//  Copyright © 2016 ShinyCroospulle. All rights reserved.
//

#import "userClass.h"
@interface userClass ()

@end
@implementation userClass

@synthesize uFirstName, uLastName, u_id, uPassword, uLocation, uSessionCookie, uEvents, uFriends, uChats;

-(id)initWithaName:(NSString *)firstName uLastName:(NSString *)lastName u_id: (NSString *) uid uPassword: (NSString *) password uLocation: (locationClass *) location uSessionCookie: (NSString *) sessionCookie uEvents: (NSMutableArray *) events uFriends: (NSMutableArray *) friends uChats: (NSMutableArray *) chats{
    self = [super init];
    if(self){
        self.uFirstName = firstName;
        self.uLastName = lastName;
        self.u_id = uid;
        self.uPassword = password;
        self.uLocation = location;
        self.uSessionCookie = sessionCookie;
        self.uEvents = events;
        self.uFriends = friends;
        self.uChats = chats;
    }
    return self;
}



@end
